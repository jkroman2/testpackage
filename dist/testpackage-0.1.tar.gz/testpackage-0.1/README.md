# testpackage
'This library was created as an example of how to use recursion within python, examples include 3 types of sorting(Bubble Sort, Merge Sort, and Quick Sort). 4 type of recursion (Sum Array - that adds the numbers of all items in an array, Fibonacci Sequence - Returns the result of any number that you enter, Factorial - The factorial of any number is that number times the factorial of (that number minus 1), Reverse Function that will reverse any word/string that you enter )'

## building this package locally
'python setup.py sdist'

## installing this package from github
'pip install git+git@github.com:jkroman2/testpackage.git'

## updating this package from github
'pip install --upgrade git+git@github.com:jkroman2/testpackage.git'
